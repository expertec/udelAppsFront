// apps-manager.js (versión corregida - flujo server-owned)
console.log('🟢🟢🟢 apps-manager.js INICIO DE CARGA');

import { auth, db, showMessage } from './dashboard-init.js';
import { doc, onSnapshot } from 'https://www.gstatic.com/firebasejs/10.7.1/firebase-firestore.js';

console.log('🟢🟢🟢 apps-manager.js IMPORTS COMPLETADOS');

/* ==========
   Estado local
   ========== */
let selectedVideoFile = null;
let currentAnalysisId = null;

/* ==========
   Helpers UI
   ========== */
function setVideoResult(html, status = 'info') {
  const resultDiv = document.getElementById('videoAnalysisResult');
  if (!resultDiv) return;
  resultDiv.style.display = 'block';
  resultDiv.className = `analysis-result ${status}`;
  resultDiv.innerHTML = html;
}
function showLoadingState(message, details = '') {
  return `
    <div class="loading-container">
      <div class="spinner"></div>
      <p class="loading-message">${message}</p>
      ${details ? `<p class="loading-details">${details}</p>` : ''}
    </div>
  `;
}
const $ = (s) => document.querySelector(s);

/* ==========
   Modales Video
   ========== */
window.openVideoAnalyzer = function () {
  const modal = document.getElementById('videoAnalyzerModal');
  if (!modal) return;
  modal.style.display = 'flex';
  initVideoDragDrop();
};
window.closeVideoAnalyzer = function () {
  const modal = document.getElementById('videoAnalyzerModal');
  if (!modal) return;
  modal.style.display = 'none';
  resetVideoAnalyzer();
};

function resetVideoAnalyzer() {
  const fileInput = document.getElementById('videoFileInput');
  const resultDiv = document.getElementById('videoAnalysisResult');
  const previewSection = document.getElementById('videoPreviewSection');
  const uploadZone = document.getElementById('videoUploadZone');
  const videoPreview = document.getElementById('videoPreview');

  if (fileInput) fileInput.value = '';
  if (resultDiv) { resultDiv.innerHTML = ''; resultDiv.style.display = 'none'; }
  if (previewSection) previewSection.style.display = 'none';
  if (uploadZone) uploadZone.style.display = 'block';
  if (videoPreview) { videoPreview.src = ''; videoPreview.load(); }

  selectedVideoFile = null;
}

/* ==========
   Drag & Drop
   ========== */
let dragDropInitialized = false;
function initVideoDragDrop() {
  if (dragDropInitialized) return;
  const uploadZone = $('#videoUploadZone');
  if (!uploadZone) return;

  ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(ev => {
    uploadZone.addEventListener(ev, preventDefaults, false);
    document.body.addEventListener(ev, preventDefaults, false);
  });
  ['dragenter', 'dragover'].forEach(ev => {
    uploadZone.addEventListener(ev, () => uploadZone.classList.add('dragover'), false);
  });
  ['dragleave', 'drop'].forEach(ev => {
    uploadZone.addEventListener(ev, () => uploadZone.classList.remove('dragover'), false);
  });
  uploadZone.addEventListener('drop', handleVideoDrop, false);
  uploadZone.addEventListener('click', () => $('#videoFileInput')?.click());

  dragDropInitialized = true;
}
function preventDefaults(e) { e.preventDefault(); e.stopPropagation(); }
function handleVideoDrop(e) {
  const dt = e.dataTransfer;
  const files = dt.files;
  if (!files?.length) return;
  const fileInput = $('#videoFileInput');
  if (!fileInput) return;
  const dataTransfer = new DataTransfer();
  dataTransfer.items.add(files[0]);
  fileInput.files = dataTransfer.files;
  window.handleVideoSelection({ target: fileInput });
}

/* ==========
   Preview de video
   ========== */
window.handleVideoSelection = async function (evt) {
  const file = evt?.target?.files?.[0];
  if (!file) return;

  const validation = await validateVideoFile(file);
  if (!validation.valid) {
    const errorMsg = validation.errors.join('\n');
    if (window.showMessage) window.showMessage(errorMsg, 'error');
    return;
  }

  selectedVideoFile = file;
  showVideoPreview(file);
};

function showVideoPreview(file) {
  const uploadZone = document.getElementById('videoUploadZone');
  const previewSection = document.getElementById('videoPreviewSection');
  const videoPreview = document.getElementById('videoPreview');
  const fileName = document.getElementById('videoFileName');
  const fileSize = document.getElementById('videoFileSize');
  const duration = document.getElementById('videoDuration');
  const resolution = document.getElementById('videoResolution');

  if (uploadZone) uploadZone.style.display = 'none';
  if (previewSection) previewSection.style.display = 'block';

  if (videoPreview) {
    const url = URL.createObjectURL(file);
    videoPreview.src = url;
    videoPreview.load();

    videoPreview.addEventListener('loadedmetadata', function () {
      const mm = Math.floor(videoPreview.duration / 60);
      const ss = Math.floor(videoPreview.duration % 60);
      if (duration) duration.textContent = `${mm}:${String(ss).padStart(2, '0')}`;
      if (resolution) resolution.textContent = `${videoPreview.videoWidth} × ${videoPreview.videoHeight}`;
    }, { once: true });
  }

  if (fileName) fileName.textContent = file.name;
  if (fileSize) fileSize.textContent = `${(file.size / (1024 * 1024)).toFixed(2)} MB`;
  if (duration) duration.textContent = 'Cargando...';
  if (resolution) resolution.textContent = 'Cargando...';
}

window.cancelVideoPreview = function () {
  const uploadZone = document.getElementById('videoUploadZone');
  const previewSection = document.getElementById('videoPreviewSection');
  const videoPreview = document.getElementById('videoPreview');
  const fileInput = document.getElementById('videoFileInput');

  if (uploadZone) uploadZone.style.display = 'block';
  if (previewSection) previewSection.style.display = 'none';
  if (fileInput) fileInput.value = '';
  if (videoPreview) { videoPreview.src = ''; videoPreview.load(); }

  selectedVideoFile = null;
};

/* ==========
   Validaciones
   ========== */
const VIDEO_CONFIG = {
  maxSizeMB: 500,
  maxSizeBytes: 500 * 1024 * 1024,
  allowedExtensions: ['.mp4', '.avi', '.mov', '.mkv']
};
async function validateVideoFile(file) {
  const errors = [];
  const ext = file.name.substring(file.name.lastIndexOf('.')).toLowerCase();
  if (!VIDEO_CONFIG.allowedExtensions.includes(ext)) {
    errors.push(`Formato no soportado. Usa: ${VIDEO_CONFIG.allowedExtensions.join(', ')}`);
  }
  if (file.size > VIDEO_CONFIG.maxSizeBytes) {
    errors.push(`El archivo es muy grande (${(file.size / (1024 * 1024)).toFixed(2)} MB). Máximo: ${VIDEO_CONFIG.maxSizeMB} MB`);
  }
  if (file.size === 0) errors.push('El archivo está vacío');
  return { valid: errors.length === 0, errors };
}

/* ==========
   Flujo de análisis (server-owned)
   ========== */
function genAnalysisId() {
  return 'an_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 10);
}
async function postAnalyzeVideo(analysisId, file) {
  const form = new FormData();
  form.append('file', file);
  form.append('analysisId', analysisId);
  const res = await fetch(`${window.API_BASE}/analyzeVideo`, { method: 'POST', body: form });
  if (!res.ok) {
    const txt = await res.text().catch(() => '');
    throw new Error(`Error del servidor (${res.status})${txt ? `: ${txt}` : ''}`);
  }
  return res.json();
}
function renderWaiting(analysisId, file) {
  const fileSizeMB = (file.size / (1024 * 1024)).toFixed(2);
  setVideoResult(
    showLoadingState('Analizando video...', `ID: ${analysisId} · ${file.name} (${fileSizeMB} MB)`),
    'loading'
  );
}

/**
 * Listener de Firestore (solo lectura)
 * Requiere reglas: allow read: if request.auth != null; en /analyses/{id}
 */
function listenAnalysis(analysisId) {
  currentAnalysisId = analysisId;
  let unsub = null;
  unsub = onSnapshot(doc(db, 'analyses', analysisId), (snap) => {
    if (!snap.exists()) return;
    const a = snap.data();

    console.log('📡 Firestore snapshot recibido:', { status: a.status, score: a.result?.score, qualifies: a.qualifiesForVimeo });

    if (a.status === 'processing') {
      setVideoResult(showLoadingState('Procesando con IA...', 'Esto puede tardar unos minutos.'), 'loading');
    } else if (a.status === 'done') {
      const r = a.result || {};
      
      // ACTUALIZAR BOTÓN DE VIMEO EN EL HEADER
      updateVimeoHeaderButton(analysisId, a.qualifiesForVimeo, a.vimeoStatus, r.score, a.scoreThreshold, a.vimeoLink);
      
      if (!r.score && !r.summary && (!r.findings || r.findings.length === 0)) {
        setVideoResult(`
          <div class="result-header error">
            <div class="result-icon">⚠</div>
            <h3 class="result-title">Análisis Incompleto</h3>
          </div>
          <p class="error-message">No se generaron resultados. Intenta con otro video.</p>
        `, 'error');
      } else {
        setVideoResult(`
          <div class="result-header success">
            <div class="result-icon">✓</div>
            <h3 class="result-title">Análisis Completado</h3>
          </div>
          <div class="result-content">
            <div class="result-score">
              <span class="score-label">Puntaje:</span>
              <span class="score-value">${r.score ?? 0}</span>
            </div>
            <div class="result-section">
              <h4>Resumen</h4>
              <p>${r.summary || '—'}</p>
            </div>
            ${(r.findings || []).length ? `
              <div class="result-section">
                <h4>Hallazgos</h4>
                <ul class="findings-list">
                  ${r.findings.map(f => `
                    <li class="${f.ok ? 'finding-ok' : 'finding-error'}">
                      <span class="finding-icon">${f.ok ? '✅' : '❌'}</span>
                      <span class="finding-rule">${f.ruleId}:</span>
                      <span class="finding-status">${f.ok ? 'Cumple' : 'No cumple'}</span>
                      ${f.note ? `<span class="finding-note">— ${f.note}</span>` : ''}
                    </li>
                  `).join('')}
                </ul>
              </div>` : ''}
            ${Array.isArray(r.suggestions) && r.suggestions.length ? `
              <div class="result-section">
                <h4>Sugerencias</h4>
                <ul class="suggestions-list">
                  ${r.suggestions.map(s => `<li>💡 ${s}</li>`).join('')}
                </ul>
              </div>` : ''}
          </div>
        `, 'success');
      }
      unsub && unsub();
    } else if (a.status === 'error') {
      const errorDetails = a.error || 'Error desconocido';
      let userMsg = errorDetails;
      if (/timeout/i.test(errorDetails)) userMsg = 'El análisis tomó demasiado tiempo. Intenta con un video más corto.';
      if (/memory/i.test(errorDetails)) userMsg = 'El video requiere demasiada memoria. Prueba menor resolución.';
      if (/format/i.test(errorDetails)) userMsg = 'Formato no compatible. Convierte a MP4.';

      setVideoResult(`
        <div class="result-header error">
          <div class="result-icon">✕</div>
          <h3 class="result-title">Error en el Análisis</h3>
        </div>
        <p class="error-message">${userMsg}</p>
        ${userMsg !== errorDetails ? `<details style="margin-top:8px;font-size:12px;color:#6b7280;"><summary>Detalles técnicos</summary><pre>${errorDetails}</pre></details>` : ''}
      `, 'error');
      unsub && unsub();
    }
  }, (err) => {
    console.error('Error en listener de Firestore:', err);
    setVideoResult(`
      <div class="result-header error">
        <div class="result-icon">✕</div>
        <h3 class="result-title">Error de Conexión</h3>
      </div>
      <p class="error-message">No se pudo conectar con el sistema de análisis.</p>
    `, 'error');
  });
}

/* ==========
   Entradas públicas
   ========== */
window.startVideoAnalysis = async function () {
  try {
    if (!selectedVideoFile) { if (window.showMessage) window.showMessage('No hay video seleccionado', 'error'); return; }
    if (!window.auth?.currentUser) { if (window.showMessage) window.showMessage('Tu sesión ha expirado. Inicia sesión.', 'error'); return; }

    // Oculta preview y muestra área de resultados
    const previewSection = $('#videoPreviewSection');
    if (previewSection) previewSection.style.display = 'none';

    // Genera ID local y llama a tu servidor en Render
    const analysisId = genAnalysisId();

    // UI: estado inicial
    renderWaiting(analysisId, selectedVideoFile);

    // Deshabilita botón
    const btn = document.querySelector('.btn-analyze');
    btn?.setAttribute('disabled', 'disabled');
    btn?.classList.add('is-loading');

    // Llamada al backend (Render)
    await postAnalyzeVideo(analysisId, selectedVideoFile);

    // Escucha Firestore (solo lectura)
    listenAnalysis(analysisId);

  } catch (e) {
    console.error(e);
    const msg = e?.message || 'Ocurrió un error al iniciar el análisis.';
    if (window.showMessage) window.showMessage(msg, 'error');
    setVideoResult(`
      <div class="result-header error">
        <div class="result-icon">✕</div>
        <h3 class="result-title">Error</h3>
      </div>
      <p class="error-message">${msg}</p>
      <button class="btn-secondary" onclick="cancelVideoPreview()" style="margin-top:12px;">Intentar nuevamente</button>
    `, 'error');
  } finally {
    const btn = document.querySelector('.btn-analyze');
    btn?.removeAttribute('disabled');
    btn?.classList.remove('is-loading');
  }
};

/**
 * Compatibilidad: si algún lugar aún llama a handleVideoUpload,
 * redirigimos al mismo flujo directo (sin escritura del cliente).
 */
window.handleVideoUpload = async function (evt) {
  const file = evt?.target?.files?.[0] || selectedVideoFile;
  if (!file) { if (window.showMessage) window.showMessage('No hay video seleccionado', 'error'); return; }
  selectedVideoFile = file;
  await window.startVideoAnalysis();
};

/* ==========
   Carta Analyzer (UI modal simple)
   ========== */
window.openCartaAnalyzer = function () {
  const modal = document.getElementById('cartaAnalyzerModal');
  if (modal) modal.style.display = 'flex';
};
window.closeCartaAnalyzer = function () {
  const modal = document.getElementById('cartaAnalyzerModal');
  if (modal) modal.style.display = 'none';
  resetCartaAnalyzer();
};

function resetCartaAnalyzer() {
  const temaInput = document.getElementById('temaDescription');
  const resultDiv = document.getElementById('cartaAnalysisResult');
  const generatorSection = document.getElementById('cartaGeneratorSection');
  const uploadSection = document.getElementById('cartaUploadSection');

  if (temaInput) temaInput.value = '';
  if (resultDiv) { resultDiv.innerHTML = ''; resultDiv.style.display = 'none'; }
  if (generatorSection) generatorSection.style.display = 'block';
  if (uploadSection) uploadSection.style.display = 'none';
}

window.showCartaGenerator = function () {
  const generatorSection = document.getElementById('cartaGeneratorSection');
  const uploadSection = document.getElementById('cartaUploadSection');
  const resultDiv = document.getElementById('cartaAnalysisResult');

  if (generatorSection) generatorSection.style.display = 'block';
  if (uploadSection) uploadSection.style.display = 'none';
  if (resultDiv) resultDiv.style.display = 'none';
};

// Función global para generar carta descriptiva
window.generateCartaDescriptiva = async function (event) {
   console.log('🎯 generateCartaDescriptiva called');

   // Guardar referencia al botón
   const btn = event?.target;

   try {
     const temaDescription = document.getElementById('temaDescription')?.value?.trim();
     console.log('📝 Tema description:', temaDescription);

     if (!temaDescription) {
       console.log('❌ No tema description provided');
       if (window.showMessage) window.showMessage('Por favor, describe el tema de tu clase.', 'error');
       return;
     }

     if (!window.auth?.currentUser) {
       console.log('❌ No user authenticated');
       if (window.showMessage) window.showMessage('Tu sesión ha expirado. Inicia sesión.', 'error');
       return;
     }

     console.log('✅ Validation passed, starting generation');

     // Mostrar loading
     const resultDiv = document.getElementById('cartaAnalysisResult');
     if (resultDiv) {
       resultDiv.innerHTML = `
         <div class="loading-container">
           <div class="spinner"></div>
           <p class="loading-message">Generando carta descriptiva con 100% garantizado...</p>
           <p class="loading-details">Aplicando IA avanzada con las mejores prácticas pedagógicas para crear una carta perfecta.</p>
         </div>
       `;
       resultDiv.style.display = 'block';
     }

     // Deshabilitar botón
     if (btn) {
       btn.disabled = true;
       btn.innerHTML = '<div class="spinner"></div> Generando carta perfecta...';
     }

    console.log('🚀 Making API call to:', `${window.API_BASE}/generateCartaDescriptiva`);
    console.log('📊 API_BASE:', window.API_BASE);

    // Llamada al backend
    const response = await fetch(`${window.API_BASE}/generateCartaDescriptiva`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ temaDescription })
    });

    console.log('📡 Response status:', response.status);

    if (!response.ok) {
      const error = await response.json().catch(() => ({ error: 'Error desconocido' }));
      console.error('❌ API Error:', error);
      throw new Error(error.error || `Error ${response.status}`);
    }

    const data = await response.json();
    console.log('✅ API Response:', data);

    // Mostrar resultado
    renderCartaResult(data);

  } catch (e) {
    console.error('❌ Error generando carta:', e);
    const resultDiv = document.getElementById('cartaAnalysisResult');
    if (resultDiv) {
      resultDiv.innerHTML = `
        <div class="result-header error">
          <div class="result-icon">✕</div>
          <h3 class="result-title">Error en la Generación</h3>
        </div>
        <p class="error-message">${e.message || 'Ocurrió un error al generar la carta descriptiva.'}</p>
      `;
      resultDiv.style.display = 'block';
    }
  } finally {
    // Restaurar botón
    if (btn) {
      btn.disabled = false;
      btn.innerHTML = `
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="margin-right: 8px;">
          <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"></path>
        </svg>
        Generar Carta Descriptiva (100% Garantizado)
      `;
    }
  }
};

function renderCartaResult(data) {
   const resultDiv = document.getElementById('cartaAnalysisResult');
   if (!resultDiv) return;

   const carta = data.carta || {};

   let html = `
     <div class="result-header success">
       <div class="result-icon">✓</div>
       <h3 class="result-title">Carta Descriptiva Generada con 100% Garantizado</h3>
       <p class="result-subtitle" style="color: #6b7280; font-size: 14px; margin: 8px 0 0 0;">
         Esta carta está optimizada para obtener la máxima puntuación en análisis pedagógico
       </p>
     </div>
     <div class="result-content">
   `;

   // Mostrar la carta generada
   if (carta.contenido) {
     // Guardar el contenido en una variable global temporal
     window.currentCartaContent = carta.contenido;

     html += `
       <div class="result-section">
         <h4>📄 Carta Descriptiva Completa</h4>
         <div class="carta-content" style="background: #f8fafc; padding: 20px; border-radius: 8px; border-left: 4px solid #22c55e; margin: 16px 0; font-size: 15px; line-height: 1.7;">
           <div style="white-space: pre-wrap; font-family: inherit; margin: 0; color: #1f2937;">${carta.contenido}</div>
         </div>
         <div style="margin-top: 16px; display: flex; gap: 12px; flex-wrap: wrap;">
           <button class="btn-primary" onclick="downloadCartaPDF()" style="display: inline-flex; align-items: center; gap: 8px;">
             📄 Descargar como PDF
           </button>
           <button class="btn-secondary" onclick="copyCartaToClipboard()" style="display: inline-flex; align-items: center; gap: 8px;">
             📋 Copiar al Portapapeles
           </button>
           <button class="btn-secondary" onclick="printCarta()" style="display: inline-flex; align-items: center; gap: 8px;">
             🖨️ Imprimir
           </button>
         </div>
       </div>
     `;
   }

   html += `</div>`;

   resultDiv.innerHTML = html;
   resultDiv.style.display = 'block';
 }

window.downloadCartaPDF = async function () {
   try {
     if (!window.currentCartaContent) {
       if (window.showMessage) window.showMessage('No hay carta disponible para descargar', 'error');
       return;
     }

     // Usar jsPDF para generar PDF
     const { jsPDF } = window.jspdf;
     const doc = new jsPDF();

     // Configurar fuente y tamaño
     doc.setFont('helvetica', 'normal');
     doc.setFontSize(12);

     // Título
     doc.setFontSize(16);
     doc.setFont('helvetica', 'bold');
     doc.text('Carta Descriptiva de Curso', 20, 30);

     doc.setFontSize(10);
     doc.setFont('helvetica', 'normal');
     doc.text('Generada automáticamente con estándares pedagógicos de calidad', 20, 40);

     // Línea separadora
     doc.setLineWidth(0.5);
     doc.line(20, 45, 190, 45);

     // Contenido de la carta
     doc.setFontSize(11);
     const splitContent = doc.splitTextToSize(window.currentCartaContent, 170);
     doc.text(splitContent, 20, 55);

     // Pie de página
     const pageHeight = doc.internal.pageSize.height;
     doc.setFontSize(8);
     doc.setTextColor(128, 128, 128);
     doc.text('Generado por UDEL Tools - Sistema de Análisis Pedagógico', 20, pageHeight - 20);

     // Descargar
     doc.save('carta-descriptiva.pdf');

     if (window.showMessage) window.showMessage('Carta descargada como PDF', 'success');
   } catch (e) {
     console.error('Error generando PDF:', e);
     if (window.showMessage) window.showMessage('Error al generar PDF. Intenta imprimir en su lugar.', 'error');
   }
 };

window.copyCartaToClipboard = async function () {
    try {
      if (!window.currentCartaContent) {
        if (window.showMessage) window.showMessage('No hay carta disponible para copiar', 'error');
        return;
      }

      await navigator.clipboard.writeText(window.currentCartaContent);
      if (window.showMessage) window.showMessage('Carta copiada al portapapeles', 'success');
    } catch (e) {
      console.error('Error copiando:', e);
      if (window.showMessage) window.showMessage('Error al copiar al portapapeles', 'error');
    }
  };

window.printCarta = function () {
    if (!window.currentCartaContent) {
      if (window.showMessage) window.showMessage('No hay carta disponible para imprimir', 'error');
      return;
    }

    const printWindow = window.open('', '_blank');
    printWindow.document.write(`
      <html>
        <head>
          <title>Carta Descriptiva</title>
          <style>
            body { font-family: Arial, sans-serif; margin: 40px; line-height: 1.6; }
            h1, h2, h3 { color: #333; margin-top: 24px; }
            p { margin: 12px 0; }
            .header { border-bottom: 2px solid #22c55e; padding-bottom: 16px; margin-bottom: 24px; }
            @media print { body { margin: 20px; } }
          </style>
        </head>
        <body>
          <div class="header">
            <h1>Carta Descriptiva de Curso</h1>
            <p><em>Generada automáticamente con estándares pedagógicos de calidad</em></p>
          </div>
          <div style="white-space: pre-wrap;">${window.currentCartaContent}</div>
        </body>
      </html>
    `);
    printWindow.document.close();
    printWindow.print();
  };

window.handleCartaUpload = function (event) {
  // Función placeholder para subida manual de cartas
  if (window.showMessage) window.showMessage('Función de análisis manual no implementada aún. Usa el generador automático.', 'info');
};

/* ==========
   Botón de Vimeo en el Header
   ========== */
function updateVimeoHeaderButton(analysisId, qualifies, vimeoStatus, score, threshold, vimeoLink) {
  console.log('🔵 updateVimeoHeaderButton:', { analysisId, qualifies, vimeoStatus, score, threshold });

  const btn = document.getElementById('btnVimeoHeader');
  if (!btn) {
    console.error('❌ Botón btnVimeoHeader no encontrado');
    return;
  }

  console.log('✅ Botón encontrado, actualizando...');

  if (vimeoStatus === 'uploaded' && vimeoLink) {
    // Ya subido - mostrar link
    btn.style.display = 'inline-flex';
    btn.disabled = false;
    btn.style.background = 'linear-gradient(135deg, #22c55e 0%, #16a34a 100%)';
    btn.innerHTML = `
      <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
        <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/>
      </svg>
      Ver en Vimeo
    `;
    btn.onclick = () => window.open(vimeoLink, '_blank');
  } else if (vimeoStatus === 'uploading') {
    // Subiendo
    btn.style.display = 'inline-flex';
    btn.disabled = true;
    btn.innerHTML = '<div class="spinner"></div> Subiendo...';
  } else if (qualifies) {
    // Califica - botón habilitado
    btn.style.display = 'inline-flex';
    btn.disabled = false;
    btn.style.background = 'linear-gradient(135deg, #0ea5e9 0%, #0284c7 100%)';
    btn.innerHTML = `
      <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
        <path d="M23.977 6.416c-.105 2.338-1.739 5.543-4.894 9.609-3.268 4.247-6.026 6.37-8.29 6.37-1.409 0-2.578-1.294-3.553-3.881L5.322 11.4C4.603 8.816 3.834 7.522 3.01 7.522c-.179 0-.806.378-1.881 1.132L0 7.197a315.065 315.065 0 0 0 3.501-3.128C5.08 2.701 6.266 1.984 7.055 1.91c1.867-.18 3.016 1.1 3.447 3.838.465 2.953.789 4.789.971 5.507.537 2.45 1.131 3.674 1.776 3.674.502 0 1.256-.796 2.265-2.385 1.004-1.589 1.54-2.797 1.612-3.628.144-1.371-.395-2.061-1.614-2.061-.574 0-1.167.121-1.777.391 1.186-3.868 3.434-5.757 6.762-5.637 2.473.06 3.628 1.664 3.493 4.797l-.013.01z"/>
      </svg>
      Subir a Vimeo
    `;
    btn.onclick = () => uploadToVimeoFromHeader();
  } else {
    // No califica - botón deshabilitado
    btn.style.display = 'inline-flex';
    btn.disabled = true;
    btn.style.background = '#94a3b8';
    btn.style.opacity = '0.6';
    btn.title = `Necesitas ${threshold || 10}% (tienes ${(score || 0).toFixed(1)}%)`;
    btn.innerHTML = `
      <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
        <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"/>
      </svg>
      No califica (${(score || 0).toFixed(1)}%)
    `;
  }
}

async function uploadToVimeoFromHeader() {
  if (!currentAnalysisId) {
    if (window.showMessage) window.showMessage('No hay análisis activo', 'error');
    return;
  }

  if (!selectedVideoFile) {
    if (window.showMessage) window.showMessage('El archivo de video ya no está disponible', 'error');
    return;
  }

  const btn = document.getElementById('btnVimeoHeader');
  if (!btn) return;

  try {
    btn.disabled = true;
    btn.innerHTML = '<div class="spinner"></div> Subiendo...';

    const form = new FormData();
    form.append('file', selectedVideoFile);
    form.append('analysisId', currentAnalysisId);

    const res = await fetch(`${window.API_BASE}/uploadToVimeo`, {
      method: 'POST',
      body: form
    });

    const data = await res.json();

    if (!res.ok) {
      throw new Error(data.error || 'Error al subir a Vimeo');
    }

    console.log('✅ Video subido a Vimeo:', data.vimeoLink);
    
    // Actualizar la UI directamente, sin depender solo del listener de Firestore
    if (data.vimeoLink) {
      btn.disabled = false;
      btn.classList.remove('uploading');
      btn.style.background = 'linear-gradient(135deg, #22c55e 0%, #16a34a 100%)';
      btn.innerHTML = `
        <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
          <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/>
        </svg>
        Ver en Vimeo
      `;
      btn.onclick = () => window.open(data.vimeoLink, '_blank');
      
      // Mostrar mensaje de éxito
      if (window.showMessage) window.showMessage('Video subido exitosamente a Vimeo', 'success');
    }

  } catch (err) {
    console.error('❌ Error al subir:', err);
    alert(err.message || 'Ocurrió un error al subir el video a Vimeo.');
    
    // Restaurar botón
    btn.disabled = false;
    btn.classList.remove('uploading');
    btn.innerHTML = `
      <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
        <path d="M23.977 6.416c-.105 2.338-1.739 5.543-4.894 9.609-3.268 4.247-6.026 6.37-8.29 6.37-1.409 0-2.578-1.294-3.553-3.881L5.322 11.4C4.603 8.816 3.834 7.522 3.01 7.522c-.179 0-.806.378-1.881 1.132L0 7.197a315.065 315.065 0 0 0 3.501-3.128C5.08 2.701 6.266 1.984 7.055 1.91c1.867-.18 3.016 1.1 3.447 3.838.465 2.953.789 4.789.971 5.507.537 2.45 1.131 3.674 1.776 3.674.502 0 1.256-.796 2.265-2.385 1.004-1.589 1.54-2.797 1.612-3.628.144-1.371-.395-2.061-1.614-2.061-.574 0-1.167.121-1.777.391 1.186-3.868 3.434-5.757 6.762-5.637 2.473.06 3.628 1.664 3.493 4.797l-.013.01z"/>
      </svg>
      Subir a Vimeo
    `;
  }
}

window.uploadToVimeoFromHeader = uploadToVimeoFromHeader;

/* ==========
    Gestión de Usuarios (Admin)
    ========== */

import {
    collection,
    query,
    where,
    orderBy,
    getDocs,
    updateDoc,
    deleteDoc
} from 'https://www.gstatic.com/firebasejs/10.7.1/firebase-firestore.js';

window.loadPendingUsers = async function loadPendingUsers() {
    try {
        const container = document.getElementById('pendingUsersContainer');
        if (!container) return;

        const q = query(
            collection(db, 'users'),
            where('approved', '==', false),
            orderBy('createdAt', 'desc')
        );

        const snapshot = await getDocs(q);

        if (snapshot.empty) {
            container.innerHTML = '<p class="no-data">No hay usuarios pendientes de aprobación.</p>';
            return;
        }

        let html = '<div class="users-grid">';
        snapshot.forEach(doc => {
            const user = { id: doc.id, ...doc.data() };
            html += `
                <div class="user-card pending">
                    <div class="user-info">
                        <div class="user-avatar">
                            ${user.photoURL ? `<img src="${user.photoURL}" alt="Avatar">` : '👤'}
                        </div>
                        <div class="user-details">
                            <h4>${user.name || 'Sin nombre'}</h4>
                            <p class="user-email">${user.email || 'Sin email'}</p>
                            <p class="user-role">Rol: ${user.role || 'user'}</p>
                            <p class="user-date">Creado: ${new Date(user.createdAt).toLocaleDateString('es-ES')}</p>
                        </div>
                    </div>
                    <div class="user-actions">
                        <button class="btn-approve" onclick="approveUser('${user.id}')">
                            ✅ Aprobar
                        </button>
                        <button class="btn-reject" onclick="rejectUser('${user.id}')">
                            ❌ Rechazar
                        </button>
                    </div>
                </div>
            `;
        });
        html += '</div>';
        container.innerHTML = html;

    } catch (error) {
        console.error('Error loading pending users:', error);
        if (window.showMessage) window.showMessage('Error al cargar usuarios pendientes.', 'error');
    }
};

window.loadAllUsers = async function loadAllUsers() {
    try {
        const container = document.getElementById('allUsersContainer');
        if (!container) return;

        const q = query(collection(db, 'users'), orderBy('createdAt', 'desc'));
        const snapshot = await getDocs(q);

        if (snapshot.empty) {
            container.innerHTML = '<p class="no-data">No hay usuarios registrados.</p>';
            return;
        }

        let html = '<div class="users-grid">';
        snapshot.forEach(doc => {
            const user = { id: doc.id, ...doc.data() };
            const statusClass = user.approved ? 'approved' : 'pending';
            const statusText = user.approved ? 'Aprobado' : 'Pendiente';

            html += `
                <div class="user-card ${statusClass}">
                    <div class="user-info">
                        <div class="user-avatar">
                            ${user.photoURL ? `<img src="${user.photoURL}" alt="Avatar">` : '👤'}
                        </div>
                        <div class="user-details">
                            <h4>${user.name || 'Sin nombre'}</h4>
                            <p class="user-email">${user.email || 'Sin email'}</p>
                            <p class="user-role">Rol: ${user.role || 'user'}</p>
                            <p class="user-status">Estado: ${statusText}</p>
                            <p class="user-date">Creado: ${new Date(user.createdAt).toLocaleDateString('es-ES')}</p>
                        </div>
                    </div>
                    <div class="user-actions">
                        ${!user.approved ? `
                            <button class="btn-approve" onclick="approveUser('${user.id}')">
                                ✅ Aprobar
                            </button>
                            <button class="btn-reject" onclick="rejectUser('${user.id}')">
                                ❌ Rechazar
                            </button>
                        ` : `
                            <button class="btn-reject" onclick="rejectUser('${user.id}')">
                                ❌ Eliminar
                            </button>
                        `}
                    </div>
                </div>
            `;
        });
        html += '</div>';
        container.innerHTML = html;

    } catch (error) {
        console.error('Error loading all users:', error);
        if (window.showMessage) window.showMessage('Error al cargar todos los usuarios.', 'error');
    }
};

window.approveUser = async function approveUser(userId) {
    try {
        const userRef = doc(db, 'users', userId);
        await updateDoc(userRef, {
            approved: true,
            approvedAt: new Date().toISOString(),
            approvedBy: auth.currentUser.uid
        });

        if (window.showMessage) window.showMessage('Usuario aprobado exitosamente.', 'success');
        // Recargar listas
        window.loadPendingUsers();
        window.loadAllUsers();

    } catch (error) {
        console.error('Error approving user:', error);
        if (window.showMessage) window.showMessage('Error al aprobar usuario.', 'error');
    }
};

window.rejectUser = async function rejectUser(userId) {
    if (!confirm('¿Estás seguro de que quieres rechazar/eliminar este usuario?')) return;

    try {
        await deleteDoc(doc(db, 'users', userId));
        if (window.showMessage) window.showMessage('Usuario eliminado.', 'success');
        // Recargar listas
        window.loadPendingUsers();
        window.loadAllUsers();

    } catch (error) {
        console.error('Error rejecting user:', error);
        if (window.showMessage) window.showMessage('Error al eliminar usuario.', 'error');
    }
};

/* ==========
    Gestión de Items (Admin)
    ========== */

window.loadAllItems = async function loadAllItems() {
    try {
        const container = document.getElementById('allItemsContainer');
        if (!container) return;

        const q = query(collection(db, 'items'), orderBy('createdAt', 'desc'));
        const snapshot = await getDocs(q);

        if (snapshot.empty) {
            container.innerHTML = '<p class="no-data">No hay items registrados.</p>';
            return;
        }

        let html = '<div class="items-grid">';
        snapshot.forEach(doc => {
            const item = { id: doc.id, ...doc.data() };
            html += `
                <div class="item-card">
                    <div class="item-info">
                        <h4>${item.title || 'Sin título'}</h4>
                        <p class="item-description">${item.description || 'Sin descripción'}</p>
                        <p class="item-date">Creado: ${new Date(item.createdAt).toLocaleDateString('es-ES')}</p>
                    </div>
                    <div class="item-actions">
                        <button class="btn-edit" onclick="editItem('${item.id}')">
                            ✏️ Editar
                        </button>
                        <button class="btn-delete" onclick="deleteItem('${item.id}')">
                            🗑️ Eliminar
                        </button>
                    </div>
                </div>
            `;
        });
        html += '</div>';
        container.innerHTML = html;

    } catch (error) {
        console.error('Error loading items:', error);
        if (window.showMessage) window.showMessage('Error al cargar items.', 'error');
    }
};

window.deleteItem = async function deleteItem(itemId) {
    if (!confirm('¿Estás seguro de que quieres eliminar este item?')) return;

    try {
        await deleteDoc(doc(db, 'items', itemId));
        if (window.showMessage) window.showMessage('Item eliminado.', 'success');
        window.loadAllItems();

    } catch (error) {
        console.error('Error deleting item:', error);
        if (window.showMessage) window.showMessage('Error al eliminar item.', 'error');
    }
};

window.editItem = function editItem(itemId) {
    // TODO: Implementar edición de items
    alert('Función de edición no implementada aún.');
};

window.openItemModal = function openItemModal() {
    // Crear modal dinámicamente si no existe
    let modal = document.getElementById('itemModal');
    if (!modal) {
        modal = document.createElement('div');
        modal.id = 'itemModal';
        modal.className = 'app-modal';
        modal.innerHTML = `
            <div class="app-modal-content">
                <div class="app-modal-header">
                    <h3 class="app-modal-title">Nuevo Item</h3>
                    <button class="app-modal-close" onclick="closeItemModal()">×</button>
                </div>
                <div class="app-modal-body">
                    <form id="itemForm">
                        <div class="form-group">
                            <label for="itemTitle">Título</label>
                            <input type="text" id="itemTitle" required>
                        </div>
                        <div class="form-group">
                            <label for="itemDescription">Descripción</label>
                            <textarea id="itemDescription" rows="4"></textarea>
                        </div>
                        <div class="form-actions">
                            <button type="button" class="btn-cancel" onclick="closeItemModal()">Cancelar</button>
                            <button type="submit" class="btn-primary">Crear Item</button>
                        </div>
                    </form>
                </div>
            </div>
        `;
        document.body.appendChild(modal);

        // Event listener para el form
        document.getElementById('itemForm').addEventListener('submit', async (e) => {
            e.preventDefault();
            await createItem();
        });
    }
    modal.style.display = 'flex';
};

window.closeItemModal = function closeItemModal() {
    const modal = document.getElementById('itemModal');
    if (modal) modal.style.display = 'none';
};

async function createItem() {
    try {
        const title = document.getElementById('itemTitle').value.trim();
        const description = document.getElementById('itemDescription').value.trim();

        if (!title) {
            if (window.showMessage) window.showMessage('El título es obligatorio.', 'error');
            return;
        }

        const itemData = {
            title,
            description,
            createdAt: new Date().toISOString(),
            createdBy: window.auth?.currentUser?.uid
        };

        await addDoc(collection(db, 'items'), itemData);

        if (window.showMessage) window.showMessage('Item creado exitosamente.', 'success');
        closeItemModal();
        window.loadAllItems();

        // Limpiar form
        document.getElementById('itemTitle').value = '';
        document.getElementById('itemDescription').value = '';

    } catch (error) {
        console.error('Error creating item:', error);
        if (window.showMessage) window.showMessage('Error al crear item.', 'error');
    }
}
