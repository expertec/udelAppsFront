// Configuración de Firebase
// IMPORTANTE: Reemplaza estos valores con tu configuración real de Firebase

export const firebaseConfig = {
      apiKey: "AIzaSyD28davZLYaw-LwNkpb-UimBXggvwFvqv8",
  authDomain: "udel-tools.firebaseapp.com",
  projectId: "udel-tools",
  storageBucket: "udel-tools.firebasestorage.app",
  messagingSenderId: "473156729973",
  appId: "1:473156729973:web:c3915b9154156e6bc58c3c",
  measurementId: "G-8D5EZNPRH7"
};