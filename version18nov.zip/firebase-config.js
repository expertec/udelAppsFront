// firebase-config.js
// Toma estos valores de: Firebase Console → Project settings → Your apps (Web)
export const firebaseConfig = {
  apiKey: "AIzaSyD28davZLYaw-LwNkpb-UimBXggvwFvqv8",
  authDomain: "udel-tools.firebaseapp.com",
  projectId: "udel-tools",
  // SUGERIDO para Storage por defecto:
  storageBucket: "udel-tools.appspot.com", // <- si en tu consola aparece otro, usa el oficial de ahí
  messagingSenderId: "473156729973",
  appId: "1:473156729973:web:c3915b9154156e6bc58c3c",
  measurementId: "G-8D5EZNPRH7"
};